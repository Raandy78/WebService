package edu.webservice.model;
public class Travel {

		private String destination;
		private int price;
		
		/**
		 * 
		 * @return name
		 */
		public String getDestination() {
			return destination;
		}
		/**
		 * 
		 * @param name
		 */
		public void setDestination(String destination) {
			this.destination = destination;
		}
		/**
		 * 
		 * @return price
		 */
		public int getPrice() {
			return price;
		}
		/**
		 * 
		 * @param price
		 */
		public void setPrice(int price) {
			this.price = price;
		}
	}


