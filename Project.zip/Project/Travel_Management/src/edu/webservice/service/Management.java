package edu.webservice.service;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import edu.webservice.model.Client;
import edu.webservice.model.Travel;

@WebService(name="Management", targetNamespace = "http://travel_management.com/")
public interface Management {
	
	@WebMethod(operationName = "logClient", action = "urn:log")
	@WebResult
	Boolean logIn(@WebParam(name = "client") Client client);
	
	@WebMethod(operationName = "signClient", action = "urn:sign")
	@WebResult
	Boolean signOut();
	
	@WebMethod(operationName = "creatClient", action = "urn:creat")
	@WebResult
	Customer createClient(@WebParam(name = "client") Client client);
	
	
	@WebMethod(operationName = "addTravel", action = "urn:add")
	@WebResult
	ArrayList<Travel> addTravel(@WebParam(name = "travel") Travel travel);
	
	@WebMethod(operationName = "deleteTravel", action = "urn:delete")
	@WebResult
	ArrayList<Travel> deleteTravel(@WebParam(name = "travel") Travel travel);
}