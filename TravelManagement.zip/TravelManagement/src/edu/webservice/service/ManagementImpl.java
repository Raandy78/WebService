
package edu.webservice.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.jws.WebService;

import edu.webservice.model.Client;
import edu.webservice.model.Travel;


@WebService(targetNamespace = "http://tavel_management.com/",
endpointInterface = "edu.webservice.service.TravelManagement",
portName = "TravelPort",
serviceName = "TravelService")
public class ManagementImpl implements Management{

	private static Boolean isConnected = false;
	private int id;
	private ArrayList<Travel> Travels = new ArrayList<Travel>();
	private ArrayList<Client> clients = new ArrayList<Client>();
	
	@Override
	public Boolean logIn(Client client) {
		if(isConnected == false) {
			for(Iterator<Client> it = clients.iterator(); it.hasNext();) {
				Client c = it.next();
				if(client.getName() == c.getName() && client.getPassword() == c.getPassword()) {
					isConnected = true;
					System.out.println("You are connected");
				}
			}
		}
		return isConnected;
	}
	
	@Override
	public Boolean signOut() {
		if(isConnected == true) {
			products.clear();
			isConnected = false;
		}
		return isConnected;
	}
	
	
	public void register() {
		Random random = new Random();
		id = random.nextInt(100);
		if(isConnected == false) {
			for(Iterator<Client> it = clients.iterator(); it.hasNext();) {
				Client c = it.next();
				if(id == c.getId()) {
					System.err.println("You are already exist");
				}
				else {
					System.out.println("User create");
				}
			}
		}
	}
	
	@Override
	public Client createClient(Client client) {
		register();
		clients.add(client);
		client.setId(id);
		return client;
	}
	
	
	
	@Override
	public ArrayList<> addTravel(Travel travel) {
		if(isConnected == true) {
			travels.add(travel);
		}
		return travels;
	}
	
	@Override
	public ArrayList<Travel> deleteTravel(Travel travel) {
		if(isConnected == true) {
			travels.remove(travel);
		}
		return travels;
	}
}

