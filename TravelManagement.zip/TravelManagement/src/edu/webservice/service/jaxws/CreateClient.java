
package edu.webservice.service.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;



@XmlRootElement(name = "creatClient", namespace = "http://travel_management.com/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "creatClient", namespace = "http://travel_management.com/")

public class CreatClient {

    @XmlElement(name = "client")
    private edu.webservice.model.Client client;

    public edu.webservice.model.Client getClient() {
        return this.client;
    }

    public void setClient(edu.webservice.model.Client newClient)  {
        this.client = newClient;
    }

}

