
package edu.webservice.service.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "addTravelResponse", namespace = "http://travel_management.com/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "addTravelResponse", namespace = "http://travel_management.com/")

public class AddTraveltResponse {

    @XmlElement(name = "return")
    private java.util.ArrayList<edu.webservice.model.Travel> _return;

    public java.util.ArrayList<edu.webservice.model.Travel> getReturn() {
        return this._return;
    }

    public void setReturn(java.util.ArrayList<edu.webservice.model.Travel> new_return)  {
        this._return = new_return;
    }

}
