
package edu.webservice.service.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement(name = "deleteTravel", namespace = "http://travel_management.com/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "deleteTravel", namespace = "http://travel_management.com/")

public class DeleteTravel {

    @XmlElement(name = "travel")
    private edu.webservice.model.Travel travel;

    public edu.webservice.model.Travel getTravel() {
        return this.travel;
    }

    public void setTravel(edu.webservice.model.Travel newTravel)  {
        this.travel = newTravel;
    }

}

