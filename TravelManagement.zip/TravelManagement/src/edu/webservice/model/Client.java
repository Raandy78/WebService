
package edu.webservice.model;

import java.util.ArrayList;



public class Client {
	private String name;
	private String firstname;
	private String password;
	private int id;
	private int money;
	private ArrayList<Travel> Cart;

	
	/**
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * 
	 * @return name
	 */
	public String getFirstname() {
		return firstname;
	}
	/**
	 * 
	 * @param name
	 */
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	/**
	 * 
	 * @return name
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * 
	 * @param name
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * 
	 * @return name
	 */
	public int getId() {
		return id;
	}
	/**
	 * 
	 * @param name
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * 
	 * @return name
	 */
	
	public ArrayList<Travel> getCart() {
		return cart;
	}
	/**
	 * 
	 * @param name
	 */
	public void setCart(ArrayList<Travel> cart) {
		this.cart = cart;
	}
	
}